# CampusOS AI — Module Handoff Manifest

> Read this before extending CampusOS in another workspace. It is the integration
> contract for merging independently built modules into the canonical codebase.

## 1. Product vision

CampusOS AI is the intelligence layer for the autonomous campus. It connects
fragmented campus workflows and turns campus data into decisions:
**Understand → Predict → Act.** It is not an ERP, not an admin dashboard, and not a
chat wrapper — it is a premium operating surface for campus operations.

## 2. Design language

Dark-first enterprise. Restrained, dense, calm, precise. Color carries meaning
(green = healthy, amber = attention, red = critical, azure = information/action).
No neon, no decorative gradients, no glassmorphism, no sparkle icons everywhere.
Motion is 150–320ms ease-out and communicates state only.

Typography: **Inter** (UI) + **IBM Plex Mono** (numeric detail), loaded via a `<link>`
in `src/routes/__root.tsx`. Never `@import` a font URL in CSS (Tailwind v4 / Lightning CSS).

## 3. Routes

| Route | Purpose |
| --- | --- |
| `/login` | Sign-in (outside the app shell) |
| `/` | Campus Command Center |
| `/copilot` | AI Campus Copilot |
| `/resources`, `/resources/:id` | Resource explorer + detail |
| `/bookings`, `/bookings/:id` | Smart bookings + detail/conflict resolution |
| `/intelligence` | Campus Intelligence Center |
| `/analytics` | Analytics |
| `/approvals`, `/activity` | Operations |
| `/notifications`, `/settings`, `/profile` | System & account |

File-based routing (TanStack Start). Every in-app route is a child of the pathless
layout `src/routes/_shell.tsx`, which renders `AppShell`. A new module page is a new
`src/routes/_shell.<name>.tsx` file — nothing else needs to change.
Never edit `src/routeTree.gen.ts`.

## 4. Component architecture

```
src/components/campusos/
  ui/primitives.tsx     Panel, PageHeader, SectionHeading, MetricCard,
                        StatusPill, StatusDot, Tag, Sparkline,
                        UtilizationBar, EmptyState, statusTone()
  layout/AppShell.tsx   Sidebar + top bar + ⌘K palette + <Outlet />
  layout/CommandPalette.tsx
  dashboard/            InsightCallout, OperationsTimeline, LiveActivity, QuickActions
  copilot/              CopilotWorkspace
```
`src/components/ui/*` is stock shadcn — customise via variants, never fork a second
design system. Keep module components under `components/campusos/<module>/` and keep
them small; route files stay thin.

## 5. Design tokens

All tokens live in `src/styles.css` (`@theme inline` + `:root`). oklch only.
Surfaces: `background`, `surface`, `surface-2`, `card`, `popover`.
Semantics: `primary`, `success`, `warning`, `destructive`, `info`, `muted`.
Lines: `border`, `border-strong`. Radius base `0.5rem`.
Typography utilities: `text-display`, `text-metric`, `text-label`, `text-meta`, `tnum`.
Surface utilities: `panel`, `panel-hover`, `grid-fade`, `enter-up`, `pulse-dot`.

**Never hardcode a color in a component** (`text-white`, `bg-[#...]`). Add a token instead.

## 6. Mock data

Everything renders from `src/data/campus.ts`. Types (`Resource`, `Booking`,
`CampusInsight`, `ActivityEvent`, `NotificationItem`) are the API contract.

## 7–8. Module boundaries & shared components

One module owns one folder under `components/campusos/` plus its route files. Modules
must not restyle primitives locally — extend `ui/primitives.tsx` so every module
inherits the change.

## 9. Dependencies

TanStack Start/Router/Query · React 19 · Tailwind v4 · shadcn/Radix · recharts ·
lucide-react · sonner · cmdk · date-fns · zod.

## 10–12. Integration points / what is mocked

Currently mocked: all campus data, Copilot reasoning (staged UI phases with a
simulated tool trace), approvals/booking mutations (toast feedback), auth (`/login`
navigates straight to `/`).

Replace, in this order, without touching UI: the service functions in
`src/data/campus.ts` → real fetches; Copilot phases → a streamed server response with
the same `thinking → tools → result` phases; toasts → real mutations + query
invalidation; `/login` → real auth with a route guard on `_shell`.

## 13. Extending CampusOS

1. Add `src/routes/_shell.<module>.tsx`, thin, with its own `head()` metadata.
2. Add `src/components/campusos/<module>/` for its components.
3. Add types + service functions to `src/data/campus.ts`.
4. Register the nav entry in `AppShell.tsx` and the command palette.
5. Use only existing primitives and tokens.

## 14. Do-not-break rules

- Do not introduce a second design system, CSS framework, or router.
- Do not hardcode colors; do not add a light theme without redefining every token.
- Do not edit `src/routeTree.gen.ts`.
- Do not remove `<Outlet />` from `__root.tsx` or `_shell.tsx`.
- Do not create dead navigation entries — every nav item must resolve to a real route.
- Do not bypass `src/data/campus.ts` with inline fixtures inside components.
