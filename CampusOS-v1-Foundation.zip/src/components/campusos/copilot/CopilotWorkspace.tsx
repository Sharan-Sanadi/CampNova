import { useEffect, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import {
  ArrowUp,
  BarChart3,
  Building2,
  CalendarPlus,
  Check,
  FileText,
  Loader2,
  Search,
  Sparkles,
  Wrench,
  AlertTriangle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Panel, StatusPill, Tag } from "@/components/campusos/ui/primitives";
import { getResource } from "@/data/campus";

type Phase = "idle" | "thinking" | "tools" | "result" | "error";

const suggestions = [
  { label: "Find a resource", icon: Search, prompt: "Find an available lab this afternoon" },
  {
    label: "Book a room",
    icon: CalendarPlus,
    prompt: "I need a 60-seat room tomorrow from 2–4 PM with a projector.",
  },
  {
    label: "Resolve a conflict",
    icon: AlertTriangle,
    prompt: "Resolve the Computer Lab 03 conflict at 14:00",
  },
  { label: "Analyze campus", icon: BarChart3, prompt: "Where is scheduling pressure highest?" },
  { label: "Summarize operations", icon: FileText, prompt: "Summarize today's campus operations" },
];

const toolTrace = [
  { label: "Parsing requirements", detail: "capacity ≥ 60 · projector · 14:00–16:00" },
  { label: "Querying resource index", detail: "34 bookable resources" },
  { label: "Checking availability", detail: "cross-referenced 148 active bookings" },
  { label: "Ranking candidates", detail: "capacity, equipment, conflict risk, history" },
];

export function CopilotWorkspace() {
  const [phase, setPhase] = useState<Phase>("idle");
  const [query, setQuery] = useState("");
  const [submitted, setSubmitted] = useState("");
  const [step, setStep] = useState(0);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, [phase]);

  const run = (text: string) => {
    if (!text.trim()) return;
    setSubmitted(text.trim());
    setQuery("");
    setPhase("thinking");
    setStep(0);
    window.setTimeout(() => setPhase("tools"), 700);
    window.setTimeout(() => setStep(1), 1000);
    window.setTimeout(() => setStep(2), 1350);
    window.setTimeout(() => setStep(3), 1700);
    window.setTimeout(() => setPhase("result"), 2200);
  };

  const best = getResource("computer-lab-04");
  const alternates = ["computer-lab-05", "classroom-112"]
    .map(getResource)
    .filter(Boolean) as NonNullable<ReturnType<typeof getResource>>[];

  return (
    <div className="mx-auto flex min-h-[calc(100dvh-9rem)] w-full max-w-3xl flex-col">
      {phase === "idle" ? (
        <div className="enter-up flex flex-1 flex-col justify-center py-10">
          <p className="text-label text-primary mb-3 flex items-center gap-2">
            <Sparkles className="size-3.5" aria-hidden /> CampusOS Copilot
          </p>
          <h1 className="text-display max-w-2xl">How can CampusOS help orchestrate your campus?</h1>
          <p className="text-muted-foreground mt-4 max-w-xl text-sm">
            Ask in natural language. CampusOS will find, reason, recommend, and act across resources,
            bookings and campus operations.
          </p>
          <div className="mt-8 flex flex-wrap gap-2">
            {suggestions.map((s) => (
              <button
                key={s.label}
                onClick={() => run(s.prompt)}
                className="border-border text-muted-foreground hover:border-border-strong hover:text-foreground inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-medium transition-colors"
              >
                <s.icon className="size-3.5" aria-hidden />
                {s.label}
              </button>
            ))}
          </div>
        </div>
      ) : (
        <div className="flex-1 space-y-5 py-2">
          <div className="flex justify-end">
            <p className="bg-surface-2 border-border max-w-xl rounded-xl rounded-br-sm border px-4 py-2.5 text-sm">
              {submitted}
            </p>
          </div>

          {/* Thinking + tool trace */}
          <Panel className="p-4 sm:p-5">
            <div className="mb-4 flex items-center gap-2">
              {phase === "result" ? (
                <Check className="text-success size-3.5" aria-hidden />
              ) : (
                <Loader2 className="text-primary size-3.5 animate-spin" aria-hidden />
              )}
              <p className="text-label text-muted-foreground">
                {phase === "thinking"
                  ? "Understanding request"
                  : phase === "tools"
                    ? "Reasoning over campus data"
                    : "Reasoning complete"}
              </p>
            </div>
            <ol className="space-y-2.5">
              {toolTrace.map((t, i) => {
                const done = phase === "result" || i < step;
                const active = phase === "tools" && i === step;
                if (phase === "thinking") return null;
                return (
                  <li key={t.label} className="flex items-start gap-2.5">
                    {done ? (
                      <Check className="text-success mt-0.5 size-3.5 shrink-0" aria-hidden />
                    ) : active ? (
                      <Loader2 className="text-primary mt-0.5 size-3.5 shrink-0 animate-spin" aria-hidden />
                    ) : (
                      <Wrench className="text-muted-foreground/50 mt-0.5 size-3.5 shrink-0" aria-hidden />
                    )}
                    <span className="min-w-0">
                      <span
                        className={
                          done || active ? "text-[13px] font-medium" : "text-muted-foreground/60 text-[13px]"
                        }
                      >
                        {t.label}
                      </span>
                      <span className="text-meta block">{t.detail}</span>
                    </span>
                  </li>
                );
              })}
            </ol>
          </Panel>

          {phase === "result" && best ? (
            <div className="enter-up space-y-4">
              <Panel className="overflow-hidden">
                <div className="border-border flex flex-wrap items-center justify-between gap-3 border-b px-5 py-3">
                  <p className="text-label text-primary">Best match</p>
                  <span className="text-xs font-medium tnum">94% match</span>
                </div>
                <div className="p-5">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="min-w-0">
                      <h2 className="text-lg font-medium tracking-tight">{best.name}</h2>
                      <p className="text-meta mt-1 flex items-center gap-1.5">
                        <Building2 className="size-3.5" aria-hidden />
                        {best.building} · {best.floor} · {best.capacity} seats
                      </p>
                    </div>
                    <StatusPill tone="success">Available · Tomorrow 14:00–16:00</StatusPill>
                  </div>
                  <div className="mt-4 flex flex-wrap gap-1.5">
                    {best.amenities.map((a) => (
                      <Tag key={a}>{a}</Tag>
                    ))}
                  </div>
                  <div className="border-border mt-5 border-t pt-4">
                    <p className="text-label text-muted-foreground mb-2.5">Why this recommendation</p>
                    <ul className="grid gap-1.5 sm:grid-cols-2">
                      {[
                        "Meets the capacity requirement",
                        "Required equipment available",
                        "No scheduling conflict",
                        "Strong historical availability",
                      ].map((r) => (
                        <li key={r} className="flex items-center gap-2 text-[13px]">
                          <Check className="text-success size-3.5 shrink-0" aria-hidden />
                          {r}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div className="mt-5 flex flex-wrap gap-2">
                    <Button
                      size="sm"
                      onClick={() =>
                        toast.success("Resource reserved", {
                          description: `${best.name} · Tomorrow 14:00–16:00 · pending approval`,
                        })
                      }
                    >
                      Reserve resource
                    </Button>
                    <Button asChild size="sm" variant="outline">
                      <Link to="/resources/$id" params={{ id: best.id }}>
                        View details
                      </Link>
                    </Button>
                    <Button asChild size="sm" variant="ghost">
                      <Link to="/resources">Compare alternatives</Link>
                    </Button>
                  </div>
                </div>
              </Panel>

              <div>
                <p className="text-label text-muted-foreground mb-2.5">Alternatives</p>
                <div className="grid gap-2.5 sm:grid-cols-2">
                  {alternates.map((r, i) => (
                    <Link
                      key={r.id}
                      to="/resources/$id"
                      params={{ id: r.id }}
                      className="panel panel-hover p-4"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <p className="truncate text-sm font-medium">{r.name}</p>
                        <span className="text-muted-foreground text-xs tnum">
                          {i === 0 ? "88%" : "74%"} match
                        </span>
                      </div>
                      <p className="text-meta mt-1">
                        {r.building} · {r.capacity} seats · {r.utilization}% utilization
                      </p>
                    </Link>
                  ))}
                </div>
              </div>
            </div>
          ) : null}
        </div>
      )}

      <form
        onSubmit={(e) => {
          e.preventDefault();
          run(query);
        }}
        className="bg-background/85 sticky bottom-0 py-4 backdrop-blur-md"
      >
        <div className="panel focus-within:border-border-strong flex items-end gap-2 p-2 transition-colors">
          <textarea
            ref={inputRef}
            rows={1}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                run(query);
              }
            }}
            placeholder="Ask CampusOS anything…"
            aria-label="Ask CampusOS"
            className="max-h-40 min-h-9 flex-1 resize-none bg-transparent px-3 py-2 text-sm outline-none"
          />
          <Button type="submit" size="icon" aria-label="Send" disabled={!query.trim()}>
            <ArrowUp className="size-4" aria-hidden />
          </Button>
        </div>
        <p className="text-muted-foreground/60 mt-2 text-[11px]">
          CampusOS reasons over live campus data. Recommendations require approval before they take
          effect.
        </p>
      </form>
    </div>
  );
}
