import { createFileRoute } from "@tanstack/react-router";
import { CopilotWorkspace } from "@/components/campusos/copilot/CopilotWorkspace";

export const Route = createFileRoute("/_shell/copilot")({
  head: () => ({
    meta: [
      { title: "AI Campus Copilot — CampusOS AI" },
      {
        name: "description",
        content:
          "Ask in natural language. CampusOS finds resources, reasons over campus data, recommends and acts.",
      },
      { property: "og:title", content: "AI Campus Copilot — CampusOS AI" },
      {
        property: "og:description",
        content: "Natural language operations for the autonomous campus.",
      },
    ],
  }),
  component: CopilotWorkspace,
});
