import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft, Building2, Check, Sparkles, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import {
  EmptyState,
  Panel,
  SectionHeading,
  Sparkline,
  StatusPill,
  Tag,
  UtilizationBar,
  statusTone,
} from "@/components/campusos/ui/primitives";
import { getBookingsForResource, getResource, type Resource } from "@/data/campus";

export const Route = createFileRoute("/_shell/resources/$id")({
  loader: ({ params }): { resource: Resource } => {
    const resource = getResource(params.id);
    if (!resource) throw notFound();
    return { resource };
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return {
        meta: [{ title: "Resource unavailable — CampusOS AI" }, { name: "robots", content: "noindex" }],
      };
    }
    const { resource } = loaderData;
    const description = `${resource.name} · ${resource.building} · ${resource.capacity} seats. Live availability, utilization and AI booking guidance.`;
    return {
      meta: [
        { title: `${resource.name} — CampusOS AI` },
        { name: "description", content: description },
        { property: "og:title", content: `${resource.name} — CampusOS AI` },
        { property: "og:description", content: description },
      ],
    };
  },
  notFoundComponent: ResourceNotFound,
  component: ResourceDetail,
});

const hours = ["08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19"];

function ResourceNotFound() {
  return (
    <EmptyState
      title="Resource not found"
      body="This resource may have been decommissioned or renamed."
      action={
        <Button asChild size="sm" variant="outline">
          <Link to="/resources">Back to resources</Link>
        </Button>
      }
    />
  );
}

function ResourceDetail() {
  const { resource } = Route.useLoaderData();
  const bookings = getBookingsForResource(resource.id);
  const busy = new Set(bookings.flatMap((b) => [b.start.slice(0, 2), b.end.slice(0, 2)]));

  return (
    <div>
      <Link
        to="/resources"
        className="text-muted-foreground hover:text-foreground mb-5 inline-flex items-center gap-1.5 text-xs font-medium transition-colors"
      >
        <ArrowLeft className="size-3.5" aria-hidden /> Resources
      </Link>

      <header className="mb-7 grid grid-cols-[minmax(0,1fr)_auto] items-start gap-4 sm:flex sm:flex-wrap sm:justify-between">
        <div className="min-w-0">
          <p className="text-label text-primary mb-2">{resource.type}</p>
          <h1 className="truncate text-2xl font-medium tracking-tight">{resource.name}</h1>
          <p className="text-muted-foreground mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm">
            <span className="inline-flex items-center gap-1.5">
              <Building2 className="size-3.5" aria-hidden />
              {resource.building} · {resource.floor}
            </span>
            <span className="inline-flex items-center gap-1.5">
              <Users className="size-3.5" aria-hidden />
              {resource.capacity} seats
            </span>
          </p>
        </div>
        <div className="flex shrink-0 flex-col items-end gap-3">
          <StatusPill tone={statusTone(resource.status)}>
            {resource.status === "in-use"
              ? "In use"
              : resource.status === "maintenance"
                ? "Maintenance"
                : "Available"}
          </StatusPill>
          <Button
            size="sm"
            onClick={() =>
              toast.success("Booking request submitted", {
                description: `${resource.name} · pending approval`,
              })
            }
          >
            Book this resource
          </Button>
        </div>
      </header>

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1.6fr)_minmax(0,1fr)]">
        <div className="space-y-6">
          <Panel className="p-5">
            <p className="text-sm leading-relaxed">{resource.description}</p>
            <div className="mt-4 flex flex-wrap gap-1.5">
              {resource.amenities.map((a: string) => (
                <Tag key={a}>{a}</Tag>
              ))}
            </div>
          </Panel>

          <section aria-label="Availability">
            <SectionHeading label="Today" title="Availability timeline" />
            <Panel className="p-5">
              <div className="flex gap-1">
                {hours.map((h) => {
                  const isBusy = busy.has(h);
                  return (
                    <div key={h} className="flex-1 text-center">
                      <div
                        className={`h-10 rounded-sm ${isBusy ? "bg-warning/70" : "bg-success/25"}`}
                        title={`${h}:00 ${isBusy ? "booked" : "free"}`}
                      />
                      <span className="text-muted-foreground/70 mt-1.5 block text-[10px] tnum">{h}</span>
                    </div>
                  );
                })}
              </div>
              <div className="text-muted-foreground mt-4 flex gap-4 text-[11px]">
                <span className="inline-flex items-center gap-1.5">
                  <span className="bg-success/25 size-2 rounded-sm" aria-hidden /> Free
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <span className="bg-warning/70 size-2 rounded-sm" aria-hidden /> Booked
                </span>
              </div>
            </Panel>
          </section>

          <section aria-label="Upcoming bookings">
            <SectionHeading label="Schedule" title="Upcoming bookings" />
            {bookings.length === 0 ? (
              <EmptyState
                title="No upcoming bookings"
                body="This resource is fully open for the next seven days."
              />
            ) : (
              <Panel className="divide-border divide-y">
                {bookings.map((b) => (
                  <Link
                    key={b.id}
                    to="/bookings/$id"
                    params={{ id: b.id }}
                    className="hover:bg-surface-2 flex items-center gap-4 px-5 py-3.5 transition-colors"
                  >
                    <span className="text-muted-foreground w-24 shrink-0 text-xs tnum">
                      {b.date.slice(5)} · {b.start}
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-[13px] font-medium">{b.title}</span>
                      <span className="text-meta block truncate">{b.organiser}</span>
                    </span>
                    <StatusPill tone={statusTone(b.status)}>{b.status}</StatusPill>
                  </Link>
                ))}
              </Panel>
            )}
          </section>
        </div>

        <div className="space-y-6">
          <Panel className="p-5">
            <p className="text-label text-muted-foreground">Weekly utilization</p>
            <p className="text-metric mt-3">{resource.utilization}%</p>
            <div className="mt-3">
              <UtilizationBar value={resource.utilization} />
            </div>
            <p className="text-meta mt-4">Seven-day usage trend</p>
            <Sparkline values={resource.trend} className="mt-1.5 h-10" />
          </Panel>

          <Panel className="p-5">
            <div className="mb-3 flex items-center gap-2">
              <Sparkles className="text-primary size-3.5" aria-hidden />
              <p className="text-label text-primary">CampusOS recommendation</p>
            </div>
            <p className="text-sm leading-relaxed">
              CampusOS recommends this resource for capacity-heavy sessions because it satisfies 4/4
              typical requirements.
            </p>
            <ul className="mt-4 space-y-1.5">
              {[
                `Capacity headroom for ${resource.capacity} attendees`,
                "Equipment matches common lab requests",
                "Conflict rate below campus average",
                "Predictable weekly availability",
              ].map((r) => (
                <li key={r} className="flex items-start gap-2 text-[13px]">
                  <Check className="text-success mt-0.5 size-3.5 shrink-0" aria-hidden />
                  {r}
                </li>
              ))}
            </ul>
          </Panel>
        </div>
      </div>
    </div>
  );
}
