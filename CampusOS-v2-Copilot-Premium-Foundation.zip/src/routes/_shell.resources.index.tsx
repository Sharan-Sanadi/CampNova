import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Search } from "lucide-react";
import {
  EmptyState,
  PageHeader,
  Sparkline,
  StatusPill,
  Tag,
  UtilizationBar,
  statusTone,
} from "@/components/campusos/ui/primitives";
import { Input } from "@/components/ui/input";
import { getResources, type ResourceType } from "@/data/campus";

export const Route = createFileRoute("/_shell/resources/")({
  head: () => ({
    meta: [
      { title: "Resource Intelligence — CampusOS AI" },
      {
        name: "description",
        content:
          "Find the right space, equipment or facility across campus with live availability and utilization.",
      },
      { property: "og:title", content: "Resource Intelligence — CampusOS AI" },
      {
        property: "og:description",
        content: "A premium operational explorer for every bookable campus resource.",
      },
    ],
  }),
  component: ResourcesPage,
});

const types: (ResourceType | "All")[] = [
  "All",
  "Computer Lab",
  "Physics Lab",
  "Classroom",
  "Meeting Room",
  "Auditorium",
  "Sports Facility",
];

function ResourcesPage() {
  const [q, setQ] = useState("");
  const [type, setType] = useState<(typeof types)[number]>("All");
  const [availableOnly, setAvailableOnly] = useState(false);

  const resources = useMemo(() => {
    return getResources().filter((r) => {
      const matchesQ =
        !q ||
        `${r.name} ${r.building} ${r.type} ${r.amenities.join(" ")}`
          .toLowerCase()
          .includes(q.toLowerCase());
      const matchesType = type === "All" || r.type === type;
      const matchesAvail = !availableOnly || r.status === "available";
      return matchesQ && matchesType && matchesAvail;
    });
  }, [q, type, availableOnly]);

  return (
    <div>
      <PageHeader
        eyebrow="Resource intelligence"
        title="Resources"
        subtitle="Find the right space, equipment, or facility for what you need."
      />

      <div className="mb-5 space-y-3">
        <div className="relative max-w-xl">
          <Search
            className="text-muted-foreground pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2"
            aria-hidden
          />
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search rooms, labs, auditoriums, equipment…"
            aria-label="Search resources"
            className="bg-surface pl-9"
          />
        </div>
        <div className="flex flex-wrap items-center gap-1.5">
          {types.map((t) => (
            <button
              key={t}
              onClick={() => setType(t)}
              aria-pressed={type === t}
              className={`rounded-full border px-3 py-1.5 text-xs font-medium transition-colors ${
                type === t
                  ? "border-primary/40 bg-primary-soft text-primary"
                  : "border-border text-muted-foreground hover:text-foreground hover:border-border-strong"
              }`}
            >
              {t}
            </button>
          ))}
          <span className="bg-border mx-1 hidden h-4 w-px sm:block" />
          <button
            onClick={() => setAvailableOnly((v) => !v)}
            aria-pressed={availableOnly}
            className={`rounded-full border px-3 py-1.5 text-xs font-medium transition-colors ${
              availableOnly
                ? "border-success/40 text-success bg-success/10"
                : "border-border text-muted-foreground hover:text-foreground hover:border-border-strong"
            }`}
          >
            Available now
          </button>
        </div>
      </div>

      {resources.length === 0 ? (
        <EmptyState
          title="No resources match these filters"
          body="Try widening the resource type or clearing the availability filter."
        />
      ) : (
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {resources.map((r, i) => (
            <Link
              key={r.id}
              to="/resources/$id"
              params={{ id: r.id }}
              className="panel panel-hover enter-up flex flex-col p-5"
              style={{ animationDelay: `${i * 40}ms` }}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <h2 className="truncate text-sm font-medium">{r.name}</h2>
                  <p className="text-meta mt-1 truncate">
                    {r.building} · {r.capacity} seats
                  </p>
                </div>
                <StatusPill tone={statusTone(r.status)}>
                  {r.status === "in-use" ? "In use" : r.status === "maintenance" ? "Maintenance" : "Available"}
                </StatusPill>
              </div>

              <div className="mt-4 flex flex-wrap gap-1.5">
                {r.amenities.slice(0, 3).map((a) => (
                  <Tag key={a}>{a}</Tag>
                ))}
                {r.amenities.length > 3 ? <Tag>+{r.amenities.length - 3}</Tag> : null}
              </div>

              <div className="mt-auto pt-5">
                <div className="mb-2 flex items-end justify-between">
                  <span className="text-label text-muted-foreground">Weekly utilization</span>
                  <span className="text-sm font-medium tnum">{r.utilization}%</span>
                </div>
                <UtilizationBar value={r.utilization} />
                <div className="mt-3 flex items-center justify-between gap-3">
                  <span className="text-meta truncate">
                    {r.nextBooking ? `Next · ${r.nextBooking}` : "No upcoming bookings"}
                  </span>
                  <Sparkline values={r.trend} className="w-16" />
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
