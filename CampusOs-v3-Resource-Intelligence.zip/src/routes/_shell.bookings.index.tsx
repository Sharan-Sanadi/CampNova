import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { AlertTriangle, CalendarPlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import {
  EmptyState,
  PageHeader,
  Panel,
  SectionHeading,
  StatusPill,
  statusTone,
} from "@/components/campusos/ui/primitives";
import { getBookings, type BookingStatus } from "@/data/campus";

export const Route = createFileRoute("/_shell/bookings/")({
  head: () => ({
    meta: [
      { title: "Smart Bookings — CampusOS AI" },
      {
        name: "description",
        content:
          "Schedule campus resources with conflict detection, approval workflow and AI-assisted resolution.",
      },
      { property: "og:title", content: "Smart Bookings — CampusOS AI" },
      {
        property: "og:description",
        content: "AI-assisted scheduling across every campus resource.",
      },
    ],
  }),
  component: BookingsPage,
});

const filters: (BookingStatus | "all")[] = [
  "all",
  "pending",
  "approved",
  "conflict",
  "rejected",
  "cancelled",
];

const day = ["08", "10", "12", "14", "16", "18"];

function BookingsPage() {
  const [filter, setFilter] = useState<(typeof filters)[number]>("all");
  const bookings = getBookings().filter((b) => filter === "all" || b.status === filter);
  const conflicts = getBookings().filter((b) => b.status === "conflict");

  return (
    <div>
      <PageHeader
        eyebrow="Smart bookings"
        title="Bookings"
        subtitle="Every reservation across campus, with conflicts surfaced before they become problems."
        actions={
          <Button
            size="sm"
            onClick={() =>
              toast("New booking", { description: "Booking composer opens here in the live build." })
            }
          >
            <CalendarPlus className="size-4" aria-hidden />
            New booking
          </Button>
        }
      />

      {conflicts.length >= 2 && conflicts[0] ? (
        <Panel className="border-destructive/30 mb-6 p-5">
          <div className="mb-3 flex items-center gap-2">
            <AlertTriangle className="text-destructive size-3.5" aria-hidden />
            <p className="text-label text-destructive">Conflict detected</p>
          </div>
          <p className="text-sm font-medium">
            {conflicts[0].resourceName} · {conflicts[0].start}–{conflicts[0].end} — two requests
            overlap.
          </p>
          <p className="text-muted-foreground mt-2 text-sm">
            CampusOS recommendation: move the Robotics Club practice to Computer Lab 05.
          </p>
          <ul className="text-muted-foreground mt-3 flex flex-wrap gap-x-5 gap-y-1 text-xs">
            <li>· same capacity</li>
            <li>· same equipment</li>
            <li>· compatible time</li>
            <li>· lower utilization</li>
          </ul>
          <div className="mt-4">
            <Button asChild size="sm">
              <Link to="/bookings/$id" params={{ id: conflicts[0].id }}>
                Review recommendation
              </Link>
            </Button>
          </div>
        </Panel>
      ) : null}

      <section aria-label="Today's schedule" className="mb-8">
        <SectionHeading label="Today" title="Resource timeline" />
        <Panel className="overflow-x-auto p-5">
          <div className="min-w-[640px]">
            <div className="text-muted-foreground/70 mb-2 grid grid-cols-[140px_repeat(6,minmax(0,1fr))] text-[10px] tnum">
              <span />
              {day.map((h) => (
                <span key={h}>{h}:00</span>
              ))}
            </div>
            {["Computer Lab 03", "Computer Lab 04", "Meeting Room 201", "Classroom 112"].map(
              (room, ri) => (
                <div
                  key={room}
                  className="grid grid-cols-[140px_repeat(6,minmax(0,1fr))] items-center gap-y-2 py-1.5"
                >
                  <span className="text-muted-foreground truncate pr-3 text-xs">{room}</span>
                  {day.map((h, i) => {
                    const filled = (ri + i) % 3 === 0;
                    const clash = ri === 0 && h === "14";
                    return (
                      <div key={h} className="px-0.5">
                        <div
                          className={`h-6 rounded-sm ${
                            clash
                              ? "bg-destructive/60"
                              : filled
                                ? "bg-primary/45"
                                : "bg-surface-2"
                          }`}
                        />
                      </div>
                    );
                  })}
                </div>
              ),
            )}
          </div>
        </Panel>
      </section>

      <div className="mb-4 flex flex-wrap gap-1.5">
        {filters.map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            aria-pressed={filter === f}
            className={`rounded-full border px-3 py-1.5 text-xs font-medium capitalize transition-colors ${
              filter === f
                ? "border-primary/40 bg-primary-soft text-primary"
                : "border-border text-muted-foreground hover:text-foreground hover:border-border-strong"
            }`}
          >
            {f === "all" ? "All bookings" : f}
          </button>
        ))}
      </div>

      {bookings.length === 0 ? (
        <EmptyState title="Nothing here" body="No bookings currently carry this status." />
      ) : (
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {bookings.map((b, i) => (
            <Link
              key={b.id}
              to="/bookings/$id"
              params={{ id: b.id }}
              className="panel panel-hover enter-up min-w-0 p-5"
              style={{ animationDelay: `${i * 35}ms` }}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-muted-foreground/70 text-[11px] tnum">{b.id}</p>
                  <h2 className="mt-1 truncate text-sm font-medium">{b.title}</h2>
                </div>
                <StatusPill tone={statusTone(b.status)}>{b.status}</StatusPill>
              </div>
              <p className="text-meta mt-3 truncate">{b.resourceName}</p>
              <p className="text-meta mt-1 tnum">
                {b.date} · {b.start}–{b.end} · {b.attendees} attendees
              </p>
              <p className="border-border text-muted-foreground mt-4 border-t pt-3 text-xs">
                {b.organiser} · {b.department}
              </p>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
