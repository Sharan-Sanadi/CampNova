import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { AlertTriangle, ArrowLeft, Check, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import {
  EmptyState,
  Panel,
  SectionHeading,
  StatusPill,
  statusTone,
} from "@/components/campusos/ui/primitives";
import { getBooking } from "@/data/campus";

export const Route = createFileRoute("/_shell/bookings/$id")({
  loader: ({ params }) => {
    const booking = getBooking(params.id);
    if (!booking) throw notFound();
    return { booking };
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return {
        meta: [{ title: "Booking unavailable — CampusOS AI" }, { name: "robots", content: "noindex" }],
      };
    }
    const { booking } = loaderData;
    const description = `${booking.title} · ${booking.resourceName} · ${booking.date} ${booking.start}–${booking.end}.`;
    return {
      meta: [
        { title: `${booking.title} — CampusOS AI` },
        { name: "description", content: description },
        { property: "og:title", content: `${booking.title} — CampusOS AI` },
        { property: "og:description", content: description },
      ],
    };
  },
  notFoundComponent: () => (
    <EmptyState
      title="Booking not found"
      body="This reservation may have been cancelled or archived."
      action={
        <Button asChild size="sm" variant="outline">
          <Link to="/bookings">Back to bookings</Link>
        </Button>
      }
    />
  ),
  component: BookingDetail,
});

function BookingDetail() {
  const { booking } = Route.useLoaderData();
  const isConflict = booking.status === "conflict";

  return (
    <div>
      <Link
        to="/bookings"
        className="text-muted-foreground hover:text-foreground mb-5 inline-flex items-center gap-1.5 text-xs font-medium transition-colors"
      >
        <ArrowLeft className="size-3.5" aria-hidden /> Bookings
      </Link>

      <header className="mb-7 grid grid-cols-[minmax(0,1fr)_auto] items-start gap-4 sm:flex sm:flex-wrap sm:justify-between">
        <div className="min-w-0">
          <p className="text-label text-muted-foreground mb-2">{booking.id}</p>
          <h1 className="truncate text-2xl font-medium tracking-tight">{booking.title}</h1>
          <p className="text-muted-foreground mt-2 text-sm tnum">
            {booking.resourceName} · {booking.date} · {booking.start}–{booking.end} ·{" "}
            {booking.attendees} attendees
          </p>
        </div>
        <StatusPill tone={statusTone(booking.status)}>{booking.status}</StatusPill>
      </header>

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1.6fr)_minmax(0,1fr)]">
        <div className="space-y-6">
          {isConflict ? (
            <Panel className="border-destructive/30 p-5">
              <div className="mb-3 flex items-center gap-2">
                <AlertTriangle className="text-destructive size-3.5" aria-hidden />
                <p className="text-label text-destructive">Conflict detected</p>
              </div>
              <p className="text-sm font-medium">
                {booking.resourceName} · {booking.start}–{booking.end} — two requests overlap.
              </p>
              <p className="text-muted-foreground mt-2 text-sm">
                CampusOS recommendation: move one booking to Computer Lab 05.
              </p>
              <ul className="mt-4 grid gap-1.5 sm:grid-cols-2">
                {["same capacity", "same equipment", "compatible time", "lower utilization"].map(
                  (r) => (
                    <li key={r} className="flex items-center gap-2 text-[13px]">
                      <Check className="text-success size-3.5 shrink-0" aria-hidden />
                      {r}
                    </li>
                  ),
                )}
              </ul>
              <div className="mt-5 flex flex-wrap gap-2">
                <Button
                  size="sm"
                  onClick={() =>
                    toast.success("Recommendation applied", {
                      description: "Robotics Club practice moved to Computer Lab 05.",
                    })
                  }
                >
                  Apply recommendation
                </Button>
                <Button asChild size="sm" variant="outline">
                  <Link to="/resources/$id" params={{ id: "computer-lab-05" }}>
                    Inspect Lab 05
                  </Link>
                </Button>
              </div>
            </Panel>
          ) : null}

          <section aria-label="Request detail">
            <SectionHeading label="Request" title="Booking detail" />
            <Panel className="divide-border divide-y">
              {[
                ["Organiser", booking.organiser],
                ["Department", booking.department],
                ["Resource", booking.resourceName],
                ["Date", booking.date],
                ["Time", `${booking.start}–${booking.end}`],
                ["Attendees", String(booking.attendees)],
                ["Assessment", booking.riskLabel],
              ].map(([k, v]) => (
                <div key={k} className="grid grid-cols-[minmax(0,1fr)_auto] gap-4 px-5 py-3">
                  <span className="text-muted-foreground text-[13px]">{k}</span>
                  <span className="text-right text-[13px] font-medium">{v}</span>
                </div>
              ))}
            </Panel>
            <p className="text-meta mt-3">{booking.note}</p>
          </section>
        </div>

        <div className="space-y-6">
          <Panel className="p-5">
            <div className="mb-3 flex items-center gap-2">
              <Sparkles className="text-primary size-3.5" aria-hidden />
              <p className="text-label text-primary">CampusOS assessment</p>
            </div>
            <p className="text-metric">{booking.riskLabel.split(" ")[0]}</p>
            <p className="text-meta mt-2">{booking.riskLabel}</p>
            <div className="mt-5 space-y-2">
              <Button
                className="w-full"
                size="sm"
                onClick={() => toast.success(`${booking.id} approved`)}
              >
                Approve
              </Button>
              <Button
                className="w-full"
                size="sm"
                variant="outline"
                onClick={() => toast("Sent for review", { description: booking.id })}
              >
                Review
              </Button>
              <Button
                className="w-full"
                size="sm"
                variant="ghost"
                onClick={() => toast.error(`${booking.id} rejected`)}
              >
                Reject
              </Button>
            </div>
          </Panel>
        </div>
      </div>
    </div>
  );
}
