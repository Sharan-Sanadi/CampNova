import { createFileRoute, Link } from "@tanstack/react-router";
import { Activity, AlertTriangle, Sparkles, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import {
  PageHeader,
  Panel,
  SectionHeading,
  StatusPill,
} from "@/components/campusos/ui/primitives";
import { campusHealth, getInsights } from "@/data/campus";

export const Route = createFileRoute("/_shell/intelligence")({
  head: () => ({
    meta: [
      { title: "Campus Intelligence — CampusOS AI" },
      {
        name: "description",
        content:
          "Campus health, live signals and explainable AI insights with evidence and recommended actions.",
      },
      { property: "og:title", content: "Campus Intelligence — CampusOS AI" },
      {
        property: "og:description",
        content: "The reasoning layer behind campus operations.",
      },
    ],
  }),
  component: IntelligencePage,
});

const signals = [
  { title: "Lab demand spike", detail: "Engineering Block · 14:00–17:00", tone: "critical" as const },
  { title: "Auditorium underutilisation", detail: "Seminar Hall A · 3 weeks", tone: "warning" as const },
  { title: "Booking anomaly", detail: "Design dept · morning slots", tone: "warning" as const },
  { title: "Cancellation pattern", detail: "6 cancellations in 14 days", tone: "info" as const },
];

const severityTone = {
  critical: "critical",
  attention: "warning",
  info: "info",
} as const;

function IntelligencePage() {
  const insights = getInsights();

  return (
    <div>
      <PageHeader
        eyebrow="Campus intelligence"
        title="The campus brain"
        subtitle="CampusOS continuously reads operational signals, explains what changed, and proposes the next action."
      />

      <div className="mb-8 grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
        <Panel className="p-5 xl:col-span-1">
          <p className="text-label text-muted-foreground">Campus health</p>
          <p className="text-metric text-success mt-3">{campusHealth.score}</p>
          <p className="text-meta mt-2">Composite operational score</p>
        </Panel>
        {[
          ["Resource utilization", `${campusHealth.utilization}%`, "Above baseline"],
          ["Booking pressure", `${campusHealth.bookingPressure}`, "Index vs. capacity"],
          ["Conflict rate", `${campusHealth.conflictRate}%`, "Of all bookings"],
          ["Pending actions", `${campusHealth.pendingActions}`, "Awaiting an operator"],
        ].map(([label, value, meaning]) => (
          <Panel key={label} className="p-5">
            <p className="text-label text-muted-foreground">{label}</p>
            <p className="text-metric mt-3">{value}</p>
            <p className="text-meta mt-2">{meaning}</p>
          </Panel>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1.6fr)_minmax(0,1fr)]">
        <section aria-label="AI insights">
          <SectionHeading label="Explainable" title="AI insights" />
          <div className="space-y-3">
            {insights.map((insight, i) => (
              <Panel key={insight.id} className="enter-up p-5" style={{ animationDelay: `${i * 50}ms` }}>
                <div className="mb-3 flex flex-wrap items-center gap-2">
                  <StatusPill tone={severityTone[insight.severity]}>
                    {insight.severity === "critical"
                      ? "Critical"
                      : insight.severity === "attention"
                        ? "Attention"
                        : "Informational"}
                  </StatusPill>
                  <span className="text-muted-foreground/70 text-[11px]">{insight.category}</span>
                </div>
                <h3 className="text-sm font-medium">{insight.title}</h3>
                <p className="text-muted-foreground mt-1.5 text-sm leading-relaxed">
                  {insight.explanation}
                </p>
                <div className="border-border mt-4 border-t pt-3">
                  <p className="text-label text-muted-foreground mb-2">Evidence</p>
                  <ul className="space-y-1">
                    {insight.evidence.map((e) => (
                      <li key={e} className="text-muted-foreground text-xs">
                        · {e}
                      </li>
                    ))}
                  </ul>
                </div>
                <p className="mt-4 text-[13px]">
                  <span className="text-primary font-medium">Recommended action — </span>
                  {insight.recommendation}
                </p>
                <div className="mt-4 flex gap-2">
                  <Button
                    size="sm"
                    onClick={() =>
                      toast.success("Recommendation queued", { description: insight.title })
                    }
                  >
                    Review
                  </Button>
                  <Button asChild size="sm" variant="ghost">
                    <Link to="/analytics">See the data</Link>
                  </Button>
                </div>
              </Panel>
            ))}
          </div>
        </section>

        <div className="space-y-6">
          <section aria-label="Live signals">
            <SectionHeading
              label="Live"
              title="Signals"
              action={<StatusPill tone="success">4 active</StatusPill>}
            />
            <Panel className="divide-border divide-y">
              {signals.map((s) => (
                <div key={s.title} className="flex items-start gap-3 px-5 py-3.5">
                  {s.tone === "critical" ? (
                    <AlertTriangle className="text-destructive mt-0.5 size-3.5 shrink-0" aria-hidden />
                  ) : s.tone === "warning" ? (
                    <TrendingUp className="text-warning mt-0.5 size-3.5 shrink-0" aria-hidden />
                  ) : (
                    <Activity className="text-primary mt-0.5 size-3.5 shrink-0" aria-hidden />
                  )}
                  <div className="min-w-0">
                    <p className="truncate text-[13px] font-medium">{s.title}</p>
                    <p className="text-meta truncate">{s.detail}</p>
                  </div>
                </div>
              ))}
            </Panel>
          </section>

          <Panel className="p-5">
            <div className="mb-3 flex items-center gap-2">
              <Sparkles className="text-primary size-3.5" aria-hidden />
              <p className="text-label text-primary">Autonomy</p>
            </div>
            <p className="text-sm leading-relaxed">
              CampusOS is currently operating in <span className="font-medium">advisory mode</span>.
              Recommendations are generated automatically but require operator approval before any
              booking changes take effect.
            </p>
            <Button asChild size="sm" variant="outline" className="mt-4">
              <Link to="/settings">Configure autonomy</Link>
            </Button>
          </Panel>
        </div>
      </div>
    </div>
  );
}
