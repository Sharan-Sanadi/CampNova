import { createFileRoute } from "@tanstack/react-router";
import {
  Capabilities,
  ClosingCta,
  CopilotSection,
  Ecosystem,
  Hero,
  ValueShift,
  Workflow,
} from "@/components/campusos/site/sections";

const title = "CampusOS AI — The Intelligence Layer for the Autonomous Campus";
const description =
  "CampusOS AI understands, predicts and acts across campus resources, bookings and operations — with an AI Copilot that reasons over real data.";

export const Route = createFileRoute("/_site/")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
    ],
  }),
  component: LandingPage,
});

function LandingPage() {
  return (
    <>
      <Hero />
      <ValueShift />
      <Workflow />
      <CopilotSection />
      <Capabilities />
      <Ecosystem />
      <ClosingCta />
    </>
  );
}
